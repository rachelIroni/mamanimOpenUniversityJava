
/**
 * This class repesent a matrix or a matrix with image filter of average
 * or a matrix with negative colors to the exist one
 * or a rotate counter clockwise matrix or a rotate clockwise matrix
 * @author Rachel ironi
 * @version (2020a)
 */
public class Matrix
{
    private final int MAX_CHART = 255;
    private final int [][] _matrix ;

    /* Constructs a matrix from a two-dimensional array; the dimensions as well as the values of this matrix 
     * will be the same as the dimensions and values of the two-dimensional array
     */
    public Matrix (int [][] array)
    {
        int row =array.length;
        int col = array[0].length;
        _matrix = new int [row][col] ;
       for (int i=0; i<array.length; i++) 
            for (int j=0; j< array[i].length; j++)
            {
                _matrix [i][j]=  array [i][j];
            }

    } 

    public Matrix (int size1,int size2 )
    /* Constructs a size 1 by size2 matrix of zeroes
     */
    {
        _matrix = new int [size1][size2];
    }

    /*represent the string of the metrix
     *@return the represent of the string's metrix
     */
    public String toString ()
    {
        String print ="";
        int count = 0;
        for (int i=0;i<_matrix.length;i++)
        {
            count = 0;
            for(int j=0;j<_matrix [i].length-1;j++)
            {
                print =print+_matrix[i][j] +"\t";
                count++;
            }

            print = print +_matrix[i][count]+ "\n";
        }
        return print;
    }

    /*returns a new metrix with the negative gray or black to white or white to black of every cell
     *@return a new metrix with the negative gray or black to white or white to black of every cell
     */
    public Matrix makeNegative()
    {
        Matrix negative = new Matrix (_matrix); //the new matrix
        for (int i=0;i<_matrix.length;i++)
        {
            for(int j=0;j<_matrix [0].length;j++)
            {
                negative._matrix [i][j] = MAX_CHART - (_matrix[i][j]); //the calculate for the negative
            }
        } 
        return negative; 
    }

    /*returns a new metrix with the average of the cell and his neighbors so there will be an image filter 
     *@return a new metrix with the average of the cell and his neighbors so there will be an image filter 
     */
    public Matrix imageFilterAverage()
    {
        Matrix copy = new Matrix (_matrix); 
        for (int i=0;i<_matrix.length;i++)
        {
            for(int j=0;j<_matrix [0].length;j++)
            {
                if (i==0 && j==0)
                    copy._matrix[i][j]=((_matrix[i][j])+(_matrix[i+1][j])+(_matrix[i+1][j+1])+(_matrix[i][j+1]))/4;
                else if (j==0 && i!=_matrix.length-1) 
                    copy._matrix[i][j]=((_matrix[i][j])+(_matrix[i+1][j])+(_matrix[i+1][j+1])+(_matrix[i][j+1])+(_matrix[i-1][j+1])+(_matrix[i-1][j]))/6;
                else if (j==0 && i==_matrix.length-1)
                    copy._matrix[i][j]=((_matrix[i][j])+(_matrix[i-1][j])+(_matrix[i-1][j+1])+(_matrix[i][j+1]))/4;
                else if (j!=0 && i==0 && j!=_matrix[0].length-1) 
                    copy._matrix[i][j]=((_matrix[i][j])+(_matrix[i+1][j])+(_matrix[i+1][j-1])+(_matrix[i][j-1])+(_matrix[i][j+1])+(_matrix[i+1][j+1]))/6;
                else if (i==0 && j==_matrix [0].length-1)
                    copy._matrix[i][j]=((_matrix[i][j])+(_matrix[i+1][j])+(_matrix[i+1][j-1])+(_matrix[i][j-1]))/4;
                else if (i==_matrix .length-1 && j==_matrix [0].length-1)
                    copy._matrix[i][j]=((_matrix[i][j])+(_matrix[i-1][j])+(_matrix[i-1][j-1])+(_matrix[i][j-1]))/4;
                else if ( j==_matrix [0].length-1)
                    copy._matrix[i][j]=((_matrix[i][j])+(_matrix[i+1][j])+(_matrix[i+1][j-1])+(_matrix[i][j-1])+(_matrix[i-1][j-1])+(_matrix[i-1][j]))/6;
                else if (i==_matrix .length-1 )
                    copy._matrix[i][j]=((_matrix[i][j])+(_matrix[i-1][j])+(_matrix[i-1][j-1])+(_matrix[i][j-1])+(_matrix[i-1][j+1])+(_matrix[i][j+1]))/6;
                else 
                    copy._matrix[i][j]=((_matrix[i][j])+(_matrix[i+1][j])+(_matrix[i+1][j-1])+(_matrix[i][j-1])+(_matrix[i-1][j-1])+(_matrix[i-1][j])+(_matrix[i-1][j+1])
                        +(_matrix[i][j+1])+(_matrix[i+1][j+1]))/9;

            }
        }
        return copy; 
    }

    /*returns a new metrix that is a rotateClockwise
     *@returns a new metrix that is a rotateClockwise
     */
    public Matrix rotateClockwise()
    {
        int toatlRowOriginal = _matrix.length;
        int toatlColOriginal = _matrix [0].length;
        int toatlRowRotrate = toatlColOriginal;
        int toatlColRotrate = toatlRowOriginal;
        int [][] rotateMatrix = new int [toatlRowRotrate][toatlColRotrate];
        for (int i = 0; i < toatlRowOriginal; i++) 
        {
            for (int j = 0; j < toatlColOriginal; j++)
            {
                rotateMatrix[j][(toatlColRotrate-1)- i] = _matrix[i][j]; //the formula puts every cell from the original columns to the new metrix row from right to left  
            } 
        } 
        return  new Matrix (rotateMatrix); 
    }

    /*returns a new metrix that is a rotateCounterClockwise
     *@returns a new metrix that is a rotateCounterClockwise
     */
    public Matrix rotateCounterClockwise()
    {
        int toatlRowOriginal = _matrix.length;
        int toatlColOriginal = _matrix [0].length;
        int toatlRowRotrate = toatlColOriginal;
        int toatlColRotrate = toatlRowOriginal;
        int [][] rotateMatrix = new int [toatlRowRotrate][toatlColRotrate];
        for (int i = 0; i < toatlRowOriginal; i++)
        {
            for (int j = 0; j < toatlColOriginal; j++)
            {
                rotateMatrix[(toatlRowRotrate-1)- j][i] = _matrix[i][j];//the formula puts every cell from the original columns to the new metrix row from left  to right
            } 
        } 
        return  new Matrix (rotateMatrix);  
    }
}


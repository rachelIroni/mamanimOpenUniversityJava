
/**
 * This program shows the stock of a supermarket
 * The client can check the number of the foodItems he has
 * He can add items, to check how many items to order,how many can move into a spcific fridge
 * To remove the items that are old from a wanted date, to check the most expensive item
 * to see all the details of items in stock, update the stock after celling the items
 * and to get the temp who can fit to all the items in the stock.
 * @author (Racheli Ironi)
 * @version (25-01-2020)
 */
public class Stock
{
    // variable
    private final int MAX_LENGTH = 100;
    private final int TAKE_OFF = 1;
    // attributes
    private FoodItem [] _stock ;
    private int _noOfItem =0;

    /**
     * Creates a new stock array which includes the fooditem object that are in the store (using the food item class and date class)
     */
    public Stock()
    {
        // default Constructor
        _stock = new FoodItem [MAX_LENGTH];
        _noOfItem = 0;
    }

    /**
     * gets the number of food items in the Stock array
     * @returns the number of food items in the Stock array   
     */
    public int getNumOfItems()
    {
        return _noOfItem;
    }

    /**
     * add the food item from the FoodItem class to stock array in Ascending ,if there is a same fooditem ecxatly it's has to merge whith the exist food item and to add the quantity
     * if there is a differnce because date or etc. it's has to be before the exist food item.
     * @param newItem the food item to add
     * @returns true if the food item was added and false if there isn't enogh room to add the food item
     */
    public boolean addItem (FoodItem newItem)
    {
        FoodItem f = new FoodItem (newItem);
        if (_noOfItem == MAX_LENGTH ) //if the array is full so there is'nt room to add any food item so the program will return false
            return false;                       
        if (_noOfItem == 0) //if the array is empty so right away you can add the food item to the first place
        {
            _stock[_noOfItem] =f;
        }
        else    //if the array is  not empty but not full untill the end
        {
            int i;
            long cNumber = f.getCatalogueNumber();
            for ( i=0; i<_noOfItem; i++)
            {   
                if (cNumber<=_stock[i].getCatalogueNumber())//to control where to add the food item
                    break;
            }

            for (int j = _noOfItem -1; j >= i; j--)
            {
                if (_stock[i].equals (f)) // if there is a food item that equals ecxatly to this one,we have to merge it together and to add the quantity
                {
                    f.setQuantity (_stock[i].getQuantity()+f.getQuantity());
                    _noOfItem--;
                    break;
                }
                _stock[j+1] = _stock[j];// mooves the cells so there will be room for the food item if needed 
            }
            _stock[i] = f;
        }

        _noOfItem++;
        return true;
    }

    /**
     * returns a string that represent all the food items that their quantity are less than the wanted amount
     * if there are a few cells of same the food item whith a difference just in date or etc. that food item will be include in this list just if the sum of all of them is less than amount 
     * @param amount the amount to compare to food item's quantity  
     * @returns a string list that represent all the food items that their quantity are less than the wanted amount
     */
    public String order (int amount)
    {
        int i;
        int count=0;
        int countI=0;//to rise the I if the cell was equals to the one after, so it won't be checked twice 
        String print="";        
        for ( i=0; i<_noOfItem-1 ; i+=1+countI)
        {   
            count=0;
            countI=0;//to rise the I if the cell was equals to the one after, so it won't be checked twice 
            count=_stock[i].getQuantity();
            for (int j=i ; j<_noOfItem-1 &&(_stock[j].getName().equals (_stock[j+1].getName())  && _stock[j].getCatalogueNumber() == _stock[j+1].getCatalogueNumber())
            ;j++) // chekcs if there are a few cells of same food item whith a difference just in date or etc. if there is he does a sum to chck all of them with the amount 

            {
                count=count+_stock[j+1].getQuantity();
                countI++;  //to rise the I if the cell was equals to the one after, so it won't be checked twice
            }

            if (count<amount)
                print = print + (_stock[i].getName() +", "); // to save the name in print 

            if ((countI+i+1)>_noOfItem)  // to control not to go back if the last cells were checked 
                break;
        }

        if ( _stock[_noOfItem-1].getCatalogueNumber() != _stock[_noOfItem-2].getCatalogueNumber())// checks the last one 
            if (_stock[_noOfItem-1].getQuantity()< amount)
                print = print + (_stock[i].getName() +"  ");
        int length=print.length();
        print = (print.substring(0,length-2)) +" "; // edit the last comma     
        return print;
    }

    /**
     * returns how many food itemd can move to a fridge with a spscific temp      
     * @param temp the temp value to be checked howmany items fit it
     * @returns how many quantity can go into this temp
     */
    public int howMany (int temp)
    {
        int i;
        int count=0;
        for ( i=0; i<_noOfItem; i++) 
        {
            if (_stock[i].getMinTemperature() < temp &&  _stock[i].getMaxTemperature()> temp)
            {
                count=count+_stock[i].getQuantity();
            }
        }
        return count;
    }

    /**
     * a private method that helps to fix all the holes of the null cells and to get rid of them      
     */
    private void fix()
    {
        int place =0;
        for (int i=0; i<_noOfItem;i++)
        {
            if (_stock[i] != null)
            {
                for(;place < i;place++)
                {
                    if (_stock[place]==null)
                    {
                        _stock[place]= _stock[i];
                        _stock[i]=null;
                        break;
                    }
                }
            }
        }
    }

    /**
     * this method deletes all the food items that their expiry date is before the entered date
     * @param d the date to compare the expiry date to be after
     */
    public void removeAfterDate (Date d)
    {
        int count=0;;
        for (int i=0; i<_noOfItem;i++)
        {
            if(!(_stock[i].isFresh(d)))
            {
                _stock[i] =null;
                count++; 
            }

        }
        fix();
        _noOfItem = _noOfItem - count;
    }

    /**
     * returns the first must expensive item from the stuck
     * @returns the first must expensive item from the stuck
     */
    public FoodItem mostExpensive ()
    {
        if (_noOfItem == 0)
            return null;
        FoodItem f = _stock[0];
        for (int i = 1; i < _noOfItem; i++)
        {
            if (f.getPrice()<(_stock[i].getPrice()))
                f = _stock[i];
        }
        return new FoodItem (f);
    }

    /**
     * returns the sum of the quantity of the whole food items in the stock
     * @returns the sum of the quantity of the whole food items in the stock
     */
    public int howManyPieces()
    {
        if (_noOfItem == 0)
            return _noOfItem ;
        int count=_stock[0].getQuantity();
        for (int i = 1; i < _noOfItem; i++)
            count = count+( _stock[i].getQuantity());
        return count;             
    }

    /**
     * returns a string that represent the whole food items in the stock array if the array is empty so it returns null
     * @returns a string that represent the whole food items in the stock array
     */
    public String toString ()
    {
        if (_noOfItem == 0)
            return null ;
        String s = _stock[0]. toString();
        for (int i = 1; i < _noOfItem; i++) 
            s= s+"\n"+(_stock[i].toString());
        return s;
    }

    /**
     * deletes from the quantity of each food item if it's on the list so it was sold
     * @param String [] itemList that gives the food items that was sold
     */
    public void updateStock (String [] itemList)
    {
        int count = 0;
        for (int i = 0; i < itemList.length; i++)
        {
            for (int j = 0; j <_noOfItem ; j++)
            {
                if (_stock[j].getName().equals(itemList[i] ))
                {         
                    _stock[j].setQuantity (_stock[j].getQuantity() -TAKE_OFF);
                    if (_stock[j].getQuantity()==0)
                    {
                        _stock[j]=null;
                        count++; 
                    }
                    break;//  if he founds an item so he does'nt have to go and tocheck and delete from the other
                }
            }
        }
        fix();// uses the frivate method to set al the null cells
        _noOfItem=_noOfItem-count;
    }

    /**
     * returns the temp that whole of the food items can be inside. if there isn't such a temperature like this so it will return the Integer.MAX_VALUE
     * @returns the temp that whole of the food items can be inside. if there isn't such a temperature like this so it will return the Integer.MAX_VALUE
     */
    public int getTempOfStock ()
    {
        if (_noOfItem == 0)
            return Integer.MAX_VALUE ;
        int min=_stock[0].getMinTemperature();
        int max=_stock[0].getMaxTemperature();
        for (int i = 1; i < _noOfItem; i++)
        {
            if (min <=_stock[i].getMinTemperature() && _stock[i].getMinTemperature() <=max)
                min=_stock[i].getMinTemperature();
            if (max>_stock[i].getMaxTemperature()&& _stock[i].getMaxTemperature()>=min)
                max=_stock[i].getMaxTemperature();
            if (min >_stock[i].getMaxTemperature() || _stock[i].getMinTemperature() > max)
                return Integer.MAX_VALUE ;

        }
        return min;
    }
}


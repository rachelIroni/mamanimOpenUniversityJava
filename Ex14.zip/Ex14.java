
/**
 * This program has two challenges
 * In the first one the client sends two strings. and the program has to send back how many times the 
 * second string appears in the first one ,no matter if there is foreign letters between,(and even if overlapped).
 * But in the same order. 
 * In the the second challenge we have to help the prince to catch the thief in a matrix (==roofs of a rectungal city)   
 * the thief location is sighned by a -1 number (if there is a thief, if not the program returns -1)
 * the other int numbers in the matrix express roof heights, the rules are that the prince can move to another roof just
 * if it's the same height, or higher in 1 value or lower in 1 or 2 value. else the prince can not jump to the other roof.
 * the progran returns the most minimal way to cath the thief and if there is no way to catch him according to the rules, 
 * the program returnes -1.
 * @author (Rachel Ironi)
 * @version (2020b)
 */
public class Ex14
{
    /** Algorythm to count how many occurrences of a given pattern 
     *appears in given String  (as sue in  subsequence)
     *@param str the contain string
     *@param pattern the string to be contained
     *@return the count number of times the pattern appears in a given String
     *(no matter if there is foreign letters between,(and even if overlapped)and in same order. 
     */

    public static int count(String str, String pattern) 
    {
        int lengthStr = str.length();//saves the length of the contain string
        int lengthPattern = pattern.length();//saves the length of the string to be Contained 
        return count(str,pattern,lengthStr,lengthPattern);//sends the two strings from client and the two int lengthes to 
        //an overloading method)
    }

    /** A private method to overload the public algorythm and help to count how many occurrences of a given pattern 
     *appears in given String  (as sue in  subsequence)
     *the trick is in every time that we had found the last character of both String and pattern matches,
     *we will 1. also exclude last character in both String and pattern and (+) 2. also exclude only last character in the Str 
     *if last character of String and pattern do not match,the recursion sends with excluding only last character in the String
     *this will give us the whole combinations      ‏‏‏‏
     *@param str the contain string
     *@param pattern the string to be contained
     *@param lengthStr the length of the contain string
     *@param lengthPattern the length of the string to be Contained 
     *@return the count number of times the pattern appears in a given String 
     */
    private static int count(String str, String pattern, int lengthStr, int lengthPattern)
    {
        // Base case 1: if only one character had been left
        if (lengthStr == 1 && lengthPattern == 1)        
            return (pattern.charAt(0) == str.charAt(0)) ? 1: 0;

        // Base case 2: if the contain String (=str) reached to its end
        if ( lengthStr == 0)        
            return 0;

        // Base case 3: if the contained string(=pattern)reached its end (that meens that we had found one whole pattern in str)
        if (lengthPattern == 0)        
            return 1;

        // Base case 4:if the length of the String to be contained (=pattern)  is bigger than the length of the contain strint (=str)
        //so it is impossible to find the pattern in the str so we will get out of this specific recursion 
        if (lengthPattern > lengthStr)        
            return 0;

        //option 1 to continue recur:  if character of String is the same one like the character of pattern so:
        //send recursion with length-1 of Str and also  length-1 of pattern (so it's excludes last character in both of them)
        //+ send recursion with one off only from the length of Str(so it's excludes last character just in str and continue 
        //serching the last character of pattern in addition to the first recursion.so we will get the whole combinations)
        if ((str.charAt(lengthStr-1) == pattern.charAt(lengthPattern-1)))
            return count(str, pattern, lengthStr - 1, lengthPattern - 1)
            + count(str, pattern, lengthStr - 1, lengthPattern);

        //option 2 to continue recur: if character of String is not the same one like the character of pattern so:
        //send recursion  with one off only from the length of Str (so it's exludes only last character in the String and continue 
        //serching the last character of pattern in this recure) 
        return count(str, pattern, lengthStr - 1, lengthPattern);    

    }

    /** In the this algorythm we have to help the prince to catch the thief in a matrix (==roofs of a rectungal city)   
     * the thief location is sighned by a -1 number (if there is a thief, if not the program returns -1)
     * the other int numbers in the matrix express roof heights, the rules are that the prince can move to another roof just
     * if it's the same height, or higher in 1 value or lower in 1 or 2 value. else the prince can not jump to the other roof.
     * the progran returns the most minimal way to cath the thief and if there is no way to catch him according to the rules, 
     * the program returnes -1
     *this is the public method which gets from the client the matrix (of roofs heights) and the first location of the prince. 
     *the method checks with helping private methods where the thief is (-1) and send all this to a overloading private method
     *@param drm the matrix express roof heights and location of thief sighned -1 (if there is one like that)
     *@param i the i's cell location to the prince to start
     *@param j the ji's cell location to the prince to start
     *@return the most minimal way to cath the thief according to the rules.*/

    public static int prince ( int  drm[][],int i, int j)
    {
        //base case 1: before we start, if the princess location is right away on the thief so we had finished
        if (drm [i][j]==-1)
            return 1;//the prince visited just one roof

        int xLocThief = checkXLocThief(drm,0,0);//checking with a private method the i location of the thief (sighned -1)
        int yLocThief = checkYLocThief(drm,0,0);//checking with a private method the j location of the thief (sighned -1)

        //base case 2:if there is no thief so we right away  go out from this algorythym and return -1        
        if (xLocThief == -10)
            return -1;

        //sending to the private over loading method: if there is a thief and he is not on the first roof with the prince
        return prince(drm, xLocThief, yLocThief,i,j,drm[i][j]);//to help finding the minimize way with sending the mat and the 
        // i and j of the prince and the i(=x) and j(=y) of the thief
    }

    /**this is the private method which gets from the public method the matrix(of roofs heights) and the first prince's location of the
     *and the thief's location. 
     *the method checks the all 4 ways from each cell
     *before checking we will save the val of this cell in temp for using it to compare the next value to this
     *and change this cell to -10. this prevents an infinite loop. 
     *if it's can't pass by until the thief because any reason ( or cell out of the mat or cell that does'nt answer the rules)
     *it will send MIN_VALUE and will fold back. because the mat is less than MAX_VAL so after folding it will get a negative
     *number. else, if the way is currect so it will stop on the thief and return one to fold the way. we will get back a 
     *possitive number. now it's the time to change the cell back to his original value so we can use it on the nxet recur
     *and we will check. if the number is negative so we do'nt want to use it so it will be MAX_VALUE
     *after finishing it will compare the minmize way and if it's nor MAX_VALUE it will return it back with +1
     *(+1 is for the first cell we had'nt count)
     *@param drm the matrix express roof heights and location of thief sighned -1 (if there is one like that)
     *@param x the i's cell location of the thief
     *param y the j's cell location of the thief
     *@param i the i's cell location to the prince to start
     *@param j the ji's cell location to the prince to start
     *@return the most minimal way to cath the thief according to the rules.*/
    private static int prince ( int  drm[][], int x, int y, int i, int j, int val)
    {
        //base case 1: if ths cell is the thief's location it had finished. and has to fold all the results back 
        if (i==x && j==y)
            return 1; 

        //base case 2: if ths cell is out of the mat or the cell does'nt fit the rules so it will giva back .MIN_VALUE and 
        //start folding back , the number at least will be negative
        if (i<0 || j<0 || i==drm.length || j==drm[0].length || (drm[i][j]!= val && drm[i][j] != val+1 && drm[i][j]!=val-1 &&
            drm[i][j]!=val-2))
            return Integer.MIN_VALUE ;

        int temp = drm [i][j];//saving the value for comparing in recurse and for correcting at the end
        drm [i][j] = -10;//changing the val to prevents an infinite loop.(can use this num because there isn't negative ecxept the -1

        int l1= prince (drm, x ,y , i+1, j , temp);//recursion trying the top cell.
        int l2= prince (drm, x ,y , i, j+1 , temp);//recursion trying the rihgt cell
        int l3= prince (drm, x ,y , i, j-1 , temp);//recursion trying the left cell
        int l4= prince (drm, x ,y , i-1, j , temp);//recursion trying the bottom cell

        drm [i][j] = temp;//changing back to its val .

        l1= l1>= 0 ? l1 : Integer.MAX_VALUE;//checking if the way is currect. if the way is negative that means that the way 
        l2= l2>= 0 ? l2 : Integer.MAX_VALUE;//is not currect so to prevent using it in calculate we should ruine it  
        l3= l3>= 0 ? l3 : Integer.MAX_VALUE;//with making it worth MAX_VALUE. 
        l4= l4>= 0 ? l4 : Integer.MAX_VALUE;

        int min = Math.min (Math.min(l1,l2),Math.min(l3,l4));//to compare and take the minmize result
        //option 1: there is a currect way
        if (min!=Integer.MAX_VALUE)
            return min + 1;
        //option 2: there is'n a currect way
        return -1;
    }

    /**this is a private method which gets from the public method the matrix(of roofs heights) and finds
     * the thief's location (sighned -1) and sends the i of this cell (num of the row)
     * @param drm the matrix to be checked to find the -1 cell
     * @param the i of the matrix that worth on the begining 0 (from the public method) to start checking from the 0,0 cell
     * @param the j of the matrix that worth on the begining 0 (from the public method) to start checking from the 0,0 cell
     * @return the i of the thief's location (sighned -1) and sends the i of this cell, if there is no -1 returns -10
     */
    private static int checkXLocThief(int  drm[][],int i,int j)
    {
        //Base case 1:it got out from the row.so it has to move to the next row and first column back. 
        if (j== drm [0]. length)
            return checkXLocThief (drm, i+1,0);
        //Base case 2: it found -1 in this cell       
        if  (drm[i][j]== -1)
            return i;
        //Base case 3:it got to the end of the matrix and did'nt find -1, so it will return -10      
        if (i==drm.length-1 && j==drm[0].length-1)
            return -10;
        //continue recursion:non of the base cases happenes so it continues the scan
        return checkXLocThief(drm,i,j+1);    
    }

    /**this is a private method which gets from the public method the matrix(of roofs heights) and finds
     * the thief's location (sighned -1) and sends the j of this cell (num of the column) 
     * @param drm the matrix to be checked to find the -1 cell
     * @param the i of the matrix that worth on the begining 0 (from the public method) to start checking from the 0,0 cell
     * @param the j of the matrix that worth on the begining 0 (from the public method) to start checking from the 0,0 cell
     * @return the j of the thief's location (sighned -1) and sends the i of this cell, if there is no -1 returns -10
     */
    private static int checkYLocThief(int  drm[][],int i,int j)
    {
        //Base case 1:it got out from the row.so it has to move to the next row and first column back.
        if (j== drm [0]. length)
            return checkYLocThief (drm, i+1,0);
        //Base case 2: it found -1 in this cell     
        if  (drm[i][j]== -1)
            return j;
        //Base case 3:it got to the end of the matrix and did'nt find -1, so it will return -10          
        if (i==drm.length-1 && j==drm[0].length-1)
            return -10;
        //continue recursion:non of the base cases happenes so it continues the scan
        return checkYLocThief(drm,i,j+1);  
    }
}

